﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Audiophile.Models
{
    public class Stock
    {

        [Key]
        public int Id { get; set; }

        [Required]
        public int stockCount { get; set; }
        
        [Required]
        [Display(Name = "Stock Name")]
        public string Name { get; set; }
    }
}
