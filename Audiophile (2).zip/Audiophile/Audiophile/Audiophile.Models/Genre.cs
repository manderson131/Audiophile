﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Audiophile.Models
{
    public class Genre
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [Display(Name="Genre")]
        public String Name { get; set; }

        [Required]
        [Display(Name = "Display Order")]
        public int DisplayOrder { get; set; }


    }
}
