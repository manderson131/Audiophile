﻿using Audiophile.DataAccess.Data.Repository.IRepository;
using Audiophile.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Audiophile.Areas.Admin.Controllers
{
    
    
        [Area("Admin")]
        public class StockController : Controller
        {
            private readonly IUnitOfWork _unitOfWork;

            public StockController(IUnitOfWork unitOfWork)
            {
                _unitOfWork = unitOfWork;
            }
            public IActionResult Index()
            {
                return View();
            }


            // GET: Contacts/Upsert/5
            public IActionResult Upsert(int? id)
            {
                Stock stock = new Stock();
                if (id == null)
                {

                    return View(stock);
                }

                stock = _unitOfWork.Stock.Get(id.GetValueOrDefault());
                if (stock == null)
                {
                    return NotFound();
                }
                return View(stock);
            }

            // POST: Contacts/Upsert/5
           
            [HttpPost]
            [ValidateAntiForgeryToken]
            public IActionResult Upsert(Stock stock)
            {

                if (ModelState.IsValid)
                {
                    if (stock.Id == 0)
                    {
                        _unitOfWork.Stock.Add(stock);
                    }
                    else
                    {
                        _unitOfWork.Stock.Update(stock);
                    }
                    _unitOfWork.Save();
                    return RedirectToAction(nameof(Index));
                }
                return View(stock);

            }

            #region API Calls
            [HttpGet]
            public IActionResult GetAll()
            {
                return Json(new { data = _unitOfWork.Genre.GetAll() });
            }

            [HttpDelete]
            public IActionResult Delete(int id)
            {
                var objFromDb = _unitOfWork.Genre.Get(id);
                if (objFromDb == null)
                {
                    return Json(new { Success = false, message = "Error while Deleting." });
                }

                _unitOfWork.Genre.Remove(objFromDb);
                _unitOfWork.Save();
                return Json(new { Success = true, message = "Deleted Successful." });


            }


            #endregion

        }
    
}
