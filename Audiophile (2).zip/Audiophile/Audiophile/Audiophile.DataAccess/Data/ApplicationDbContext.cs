﻿using System;
using System.Collections.Generic;
using System.Text;
using Audiophile.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Audiophile.DataAccess.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Genre> Genre { get; set; }
        public DbSet<Stock> Stock { get; set; }    
        public DbSet<Record> Record { get; set; }
    }
}
