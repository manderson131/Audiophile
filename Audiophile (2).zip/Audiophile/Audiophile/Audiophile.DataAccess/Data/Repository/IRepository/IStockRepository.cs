﻿using Audiophile.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Text;

namespace Audiophile.DataAccess.Data.Repository.IRepository
{
    public interface IStockRepository : IRepository<Stock>
    {
        IEnumerable<SelectListItem> GetStockListForDropDown();

        void Update(Stock stock);
    }
}
