﻿using Audiophile.DataAccess.Data.Repository.IRepository;
using Audiophile.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Audiophile.DataAccess.Data.Repository
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly ApplicationDbContext _db;

        public UnitOfWork(ApplicationDbContext db)
        {
            _db = db;
            Genre = new GenreRepository(_db);
            Stock = new StockRepository(_db);
            Record = new RecordRepository(_db);
        }

        public IGenreRepository Genre { get; private set; }

        public IStockRepository Stock { get; private set; }

        public IRecordRepository Record { get; private set;}

        public void Dispose()
        {
            _db.Dispose();
        }

        public void Save()
        {
            _db.SaveChanges();
        }
    }
}
